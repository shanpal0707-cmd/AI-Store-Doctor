# 🩺 AI Store Doctor

**AI-powered business assistant for smarter retail decisions**

AI Store Doctor helps small retailers understand product performance, identify products that need attention, discover business opportunities, and create AI-powered marketing content.

## 🚀 Features

- 🏪 **Store Setup** — configure store name, business type, size, and business goal.
- 📦 **Product Management** — add products, pricing, stock, units sold, and sales period.
- 🩺 **Product Doctor** — analyze product health, sales performance, profitability, inventory risks, and recommended actions.
- 📊 **Business / Market Analysis** — discover market opportunities, demand signals, pricing opportunities, category opportunities, and recommendations.
- ✍️ **AI Content Creator** — generate Instagram captions, Facebook posts, product descriptions, WhatsApp promotions, advertisements, headlines, CTAs, tips, and hashtags.
- 🤖 **Gemini AI Integration** — centralized backend AI service with JSON response handling.

## 🛠️ Tech Stack

**Frontend:** Angular, TypeScript, HTML, CSS  
**Backend:** Node.js, Express.js, REST APIs  
**AI:** Google Gemini API  
**Database:** MongoDB / Mongoose

## 📁 Project Structure

```text
AI-Store-Doctor/
├── src/                  # Angular frontend
├── public/               # Static assets
├── server/               # Express backend
│   ├── db/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   ├── services/
│   ├── index.js
│   ├── package.json
│   └── .env.example
├── angular.json
├── package.json
├── package-lock.json
├── proxy.conf.json
└── README.md
```

## ⚙️ Requirements

- Node.js and npm
- MongoDB (for the backend database)
- Google Gemini API key for AI features

## 🔧 Installation

### 1. Clone the repository

```bash
git clone <your-repository-url>
cd AI-Store-Doctor
```

### 2. Install frontend dependencies

From the project root:

```bash
npm install
```

### 3. Install backend dependencies

```bash
cd server
npm install
```

### 4. Configure environment variables

Inside the `server` folder, copy `.env.example` to `.env` and fill in your own values:

```text
PORT=3000
JWT_SECRET=your_long_random_secret
MONGODB_URI=your_mongodb_connection_string
AI_PROVIDER=gemini
GEMINI_API_KEY=your_gemini_api_key
```

`IBM_*` variables are only needed if `AI_PROVIDER=granite` is used.

**Never commit `server/.env` or any real API key, database password, or secret to GitHub.**

## ▶️ Run the Application

The frontend and backend run in separate terminals.

### Terminal 1 — Backend

```bash
cd server
npm start
```

The backend runs on:

```text
http://localhost:3000
```

### Terminal 2 — Frontend

From the project root:

```bash
npm start
```

The Angular development server runs on:

```text
http://localhost:4200
```

Open `http://localhost:4200` in your browser.

The Angular proxy forwards `/api` requests to the backend at `http://localhost:3000`.

## 🔄 Application Flow

```text
Store Setup
    ↓
Add Products
    ↓
Product Performance
    ↓
Product Doctor
    ↓
AI Business / Market Analysis
    ↓
AI Content Creator
    ↓
Marketing-ready Content
```

## 🔐 Security

- Keep all API credentials on the backend.
- Never place the Gemini API key in frontend code.
- Never commit `server/.env`.
- Use `server/.env.example` as the safe configuration template.

## 🧪 Build / Verification

Frontend build:

```bash
npm run build
```

TypeScript check:

```bash
npx tsc --noEmit --project tsconfig.app.json
```

## 🎯 Problem Solved

Small retailers often have product data but lack the time or tools to turn that data into useful decisions. AI Store Doctor converts store and product information into practical insights and marketing actions.

It helps answer questions such as:

- Which products are performing well?
- Which products need attention?
- Is inventory becoming a risk?
- Are products priced effectively?
- Where are business opportunities?
- What should the store owner do next?
- How can a product be promoted effectively?

## 📌 Project Status

**Core application: Complete**

Implemented modules include Store Setup, Dashboard, Product Management, Product Doctor, Business / Market Analysis, AI Content Creator, Gemini AI integration, product persistence, authentication, and AI response handling.

---

**AI Store Doctor — Analyze → Understand → Recommend → Act**
